1. Unzip smp360_cdb1_vm1_20170613_2120.zip into a directory
2. Review 00001_smp360_cdb1_index.html
